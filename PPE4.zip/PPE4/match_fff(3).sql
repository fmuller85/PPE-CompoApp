-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Lun 27 Janvier 2014 à 22:06
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `match_fff`
--

-- --------------------------------------------------------

--
-- Structure de la table `club`
--

CREATE TABLE IF NOT EXISTS `club` (
  `numClub` int(11) NOT NULL AUTO_INCREMENT,
  `nomClub` varchar(30) NOT NULL,
  `adresseClub` varchar(50) NOT NULL,
  `cpClub` int(5) NOT NULL,
  `villeClub` varchar(30) NOT NULL,
  `telClub` varchar(30) NOT NULL,
  `mailClub` varchar(30) NOT NULL,
  `imgClub` varchar(50) NOT NULL,
  `codeFFF` int(11) NOT NULL,
  `mdpClub` varchar(8) NOT NULL,
  PRIMARY KEY (`numClub`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `club`
--

INSERT INTO `club` (`numClub`, `nomClub`, `adresseClub`, `cpClub`, `villeClub`, `telClub`, `mailClub`, `imgClub`, `codeFFF`, `mdpClub`) VALUES
(1, 'PARIS Saint Germain', '24, rue du Commandant Guilbaud', 75781, 'PARIS Cedex 16', '0141107100', 'infos@psg.com', '', 12345, '12345'),
(2, 'Olympique de Marseille', 'La Commanderie,,33, traverse de la Martine', 13425, 'MARSEILLE', '0491765609', 'infos@om.com', '', 12346, '12345'),
(3, 'Olympique Lyonnais', '350 avenue Jean Jaures', 69007, 'LYON', '0426296700', 'infos@ol.com', '', 123457, '12345');

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

CREATE TABLE IF NOT EXISTS `joueur` (
  `id_joueur` int(11) NOT NULL AUTO_INCREMENT,
  `nom_joueur` varchar(50) DEFAULT NULL,
  `prenom_joueur` varchar(50) DEFAULT NULL,
  `datenaiss_joueur` date DEFAULT NULL,
  `photo_joueur` varchar(80) DEFAULT NULL,
  `id_club` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_joueur`),
  KEY `id_club` (`id_club`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Contenu de la table `joueur`
--

INSERT INTO `joueur` (`id_joueur`, `nom_joueur`, `prenom_joueur`, `datenaiss_joueur`, `photo_joueur`, `id_club`) VALUES
(2, 'Andres', 'Iniesta', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(3, 'Sergio', 'Busquet', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(4, 'Jordi', 'Alba', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(5, 'Neymar', 'Da Silva', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(6, 'Roberto', 'Francesco', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(7, 'Pedro', 'Rodriguez', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(9, 'Carles', 'Puyol', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(10, 'Gerard', 'Pique', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 1),
(11, 'Lionel', 'Messi', '1994-06-05', 'images/photo_joueur/joueur_inconnu.png', 2),
(12, 'Marvollo', 'Francesco', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(13, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(14, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(15, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(16, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(17, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(18, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(19, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(20, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(21, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(22, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(23, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(24, 'Marvollo', 'Roberto', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 2),
(25, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(26, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(27, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(28, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(29, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(30, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(31, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(32, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(33, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(34, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(35, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3),
(36, 'Marvollo', 'Bernardo', '0000-00-00', 'images/photo_joueur/joueur_inconnu.png', 3);

-- --------------------------------------------------------

--
-- Structure de la table `match`
--

CREATE TABLE IF NOT EXISTS `match` (
  `numMatch` int(11) NOT NULL AUTO_INCREMENT,
  `dateMatch` date NOT NULL,
  `epreuveMatch` varchar(50) NOT NULL,
  `club1` int(11) NOT NULL,
  `club2` int(11) NOT NULL,
  PRIMARY KEY (`numMatch`),
  KEY `club1` (`club1`),
  KEY `club2` (`club2`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Contenu de la table `match`
--

INSERT INTO `match` (`numMatch`, `dateMatch`, `epreuveMatch`, `club1`, `club2`) VALUES
(20, '2014-01-31', 'championnat', 2, 3);

-- --------------------------------------------------------

--
-- Structure de la table `remplacant`
--

CREATE TABLE IF NOT EXISTS `remplacant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idMatch` int(11) DEFAULT NULL,
  `idClub` int(11) DEFAULT NULL,
  `idJoueur` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatch` (`idMatch`),
  KEY `idJoueur` (`idJoueur`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

-- --------------------------------------------------------

--
-- Structure de la table `titulaire`
--

CREATE TABLE IF NOT EXISTS `titulaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idMatch` int(11) DEFAULT NULL,
  `idClub` int(11) DEFAULT NULL,
  `idJoueur` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idMatch` (`idMatch`),
  KEY `idJoueur` (`idJoueur`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=133 ;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `match`
--
ALTER TABLE `match`
  ADD CONSTRAINT `match_ibfk_1` FOREIGN KEY (`club1`) REFERENCES `club` (`numClub`),
  ADD CONSTRAINT `match_ibfk_2` FOREIGN KEY (`club2`) REFERENCES `club` (`numClub`);

--
-- Contraintes pour la table `remplacant`
--
ALTER TABLE `remplacant`
  ADD CONSTRAINT `remplacant_ibfk_1` FOREIGN KEY (`idMatch`) REFERENCES `match` (`numMatch`),
  ADD CONSTRAINT `remplacant_ibfk_2` FOREIGN KEY (`idJoueur`) REFERENCES `joueur` (`id_joueur`);

--
-- Contraintes pour la table `titulaire`
--
ALTER TABLE `titulaire`
  ADD CONSTRAINT `titulaire_ibfk_1` FOREIGN KEY (`idMatch`) REFERENCES `match` (`numMatch`),
  ADD CONSTRAINT `titulaire_ibfk_2` FOREIGN KEY (`idJoueur`) REFERENCES `joueur` (`id_joueur`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
