<div id="accueil">
Création et gestion de la composition des matchs de la FFF.
</div>