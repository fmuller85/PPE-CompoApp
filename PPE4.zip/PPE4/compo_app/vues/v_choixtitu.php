

<script>
    $(document).ready(function(){
        $(function() {
            $(".draggable").css("cursor", "pointer");

            var a = 3;
            $(".draggable").draggable({
                start: function(event, ui) {
                    $(this).css("z-index", a++);
                },
                revert: true
            });

            $(".sortableJoueur").droppable({
                drop: function( event, ui ) {
                    if($(ui.draggable).parent().attr('class') != $(this).attr('class')){
                        $(ui.draggable).appendTo('.sortableJoueur').css({top: 0,left: 0});

                        var message = "";
                        var action = "";

                        if($(ui.draggable).attr('name') == "unremp"){
                            var action = "supprimerRemp";
                            message = "remplacant supprimé";
                        }
                        if($(ui.draggable).attr('name') == "untitu"){
                            var action = "supprimerTitu";
                            message = "titulaire supprimé";
                        }
                        $(ui.draggable).attr('name', 'unjoueur');

                        var idj = $(ui.draggable).attr("id");
                        var idm = $("input[name='idmatch']").val();

                        $.ajax({
                            type:'POST',
                            url: 'traitementJoueur.php',
                            data: "action="+action+"&joueur="+idj+"&match="+idm,
                            success: function(data) {
                                //alert(message);
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                alert(jqXHR + " " + textStatus + " "+ errorThrown);
                            }
                        });
                    }
                },
                hover: function( event, ui ) {
                    $(".sortableJoueur").addClass("listehover");
                }

            })

            $(".sortableTitu").droppable({
                drop: function( event, ui ) { //lorsque l'on relache l'élément déplacable sur la liste des titu
                    if($(ui.draggable).parent().attr('class') != $(this).attr('class')){ //si l'élément déplacable n'est pas contenu dans la même liste
                        $(ui.draggable).appendTo('.sortableTitu').css({top: 0,left: 0}); //alors on ajoute l'élément déplacable à la liste des titu
                        var action = "";

                        if(ui.draggable.attr('name') == 'unremp'){ // On gère le cas ou l'on insert un titulaire depuis la liste des remplacant
                            action = "remplacantTotitu";
                        }else{
                            action = "ajouterTitu"
                        }
                        $(ui.draggable).attr('name', 'untitu');

                        var idc = $("input[name='idclub']").val();
                        var idj = $(ui.draggable).attr("id");
                        var idm = $("input[name='idmatch']").val();

                        $.ajax({
                            type:'POST',
                            url: 'traitementJoueur.php',
                            data: "action="+action+"&joueur="+idj+"&match="+idm+"&club="+idc,
                            success: function(data) {
                                //alert('Joueur ajouté');
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                alert(jqXHR + " " + textStatus + " "+ errorThrown);
                            }
                        });
                    }
                }
            })

            $(".dropRemplacant").droppable({
                drop: function( event, ui ) { //lorsque l'on relache l'élément déplacable sur la liste des titu
                    if($(ui.draggable).parent().attr('class') != $(this).attr('class')){ //si l'élément déplacable n'est pas contenu dans la même liste
                        $(ui.draggable).appendTo('.dropRemplacant').css({top: 0,left: 0}); //alors on ajoute l'élément déplacable à la liste des titu
                        var action = "";
                        if(ui.draggable.attr('name') == 'untitu'){
                            action = "tituToRemplacant";
                        }else{
                            action = "ajouterRemp"
                        }
                        $(ui.draggable).attr('name', 'unremp');

                        var idj = $(ui.draggable).attr("id");
                        var idc = $("input[name='idclub']").val();
                        var idm = $("input[name='idmatch']").val();

                        $.ajax({
                            type:'POST',
                            url: 'traitementJoueur.php',
                            data: "action="+action+"&joueur="+idj+"&match="+idm+"&club="+idc,
                            success: function(data) {
                                //alert('Joueur ajouté');
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                alert(jqXHR + " " + textStatus + " "+ errorThrown);
                            }
                        });
                    }
                }
            })
        });


    });
</script>
<h3>Choix des titulaires</h3>
<div id="map">
    <div id="listeJoueur">
        <h4>Liste des Joueurs</h4>
        <ul>
            <li><span class="col">ID</span><span class="col">NOM</span><span class="col">PRENOM</span></li>
        </ul>
        <ul class="sortableJoueur">
            <?php
            foreach($listeJoueur as $unjoueur){
                $trouve = false;
                $i = 0;
                while($i < count($joueurSelectionne) && count($joueurSelectionne) != 0 && $trouve == false){
                    if($unjoueur->getId() == $joueurSelectionne[$i]->getId()){
                        $trouve = true;
                    }
                    $i++;
                }
                if($trouve == false){
                    $nom = $unjoueur->getNom();
                    $prenom = $unjoueur->getPrenom();
                    $id = $unjoueur->getId();

                    echo "<li name='unjoueur' id='".$id."' class='draggable'>
                            <span class='col_id'>".$id."</span>
                            <span class='col_nom'>".$nom."</span>
                            <span class='col_prenom'>".$prenom."</span>
                        </li>";
                }
            }
            ?>
        </ul>
    </div>

    <div id="listeTitu">
        <h4>Liste des titulaires</h4>
        <ul>
            <li><span class="col">ID</span><span class="col">NOM</span><span class="col">PRENOM</span></li>
        </ul>
        <ul class="sortableTitu">
            <?php
            foreach($listeTitu as $unjoueur){
                $nom = $unjoueur->getNom();
                $prenom = $unjoueur->getPrenom();
                $id = $unjoueur->getId();

                echo "<li name='untitu' id='".$id."' class='draggable'>
                    <span class='col_id'>".$id."</span>
                    <span class='col_nom'>".$nom."</span>
                    <span class='col_prenom'>".$prenom."</span>
                  </li>";
            }
            ?>
        </ul>
    </div>
    <div id="listeRemp">
        <h4>Liste des remplacants</h4>
        <ul>
            <li><span class="col">ID</span><span class="col">NOM</span><span class="col">PRENOM</span></li>
        </ul>
        <ul class="dropRemplacant">
            <?php
            foreach($listeRemp as $unjoueur){
                $nom = $unjoueur->getNom();
                $prenom = $unjoueur->getPrenom();
                $id = $unjoueur->getId();

                echo "<li name='unremp' id='".$id."' class='draggable'>
                    <span class='col_id'>".$id."</span>
                    <span class='col_nom'>".$nom."</span>
                    <span class='col_prenom'>".$prenom."</span>
                  </li>";
            }
            ?>
        </ul>
    </div>
</div>

<input type="hidden" name="idclub" value="<?php echo $idclub; ?>" />
<input type="hidden" name="idmatch" value="<?php echo $idmatch; ?>" />