﻿<?php
$pseudo = "admin";
$mdp = "123";

if(isset($_POST['valider'])){
    if($_POST['login'] == $pseudo && $_POST['mdp'] == $mdp){
        header("Refresh: 0; url=index.php?uc=admin&action=newmatch");
        $uc = "admin";
        $_SESSION['uc'] = $uc;
    }else{
        require_once('/classes/ClubDAO.php');
        $login = $_POST['login'];
        $mdp = $_POST['mdp'];
        $cdao = new ClubDAO();
        $leclub = $cdao->findByLog($login, $mdp);
        if($leclub != null){

            $unclub=array();
            $unclub[0] = $leclub;

            $_SESSION['objclub'] = serialize($unclub[0]);
            $uc = "coach";
            $_SESSION['uc'] = $uc;
            header("Refresh: 0; url=index.php?uc=coach&action=viewmatch");
        }else{
            header("Refresh: 0; url=index.php?uc=accueil");
        }
    }
}

?>
<div id="login">
<form method="POST" action="index.php?uc=<?php echo $uc ?>">
   <fieldset>
     <legend>Authentification</legend>
		<p>
			<label for="login">Votre identifiant :</label>
			<input id="login" type="text" name="login"" size="8" maxlength="8">
		</p>
       <br/>
		<p>
			<label for="mdp">Mot de passe :</label>
			 <input id="mdp" type="password" name="mdp" size="30" maxlength="50">
		</p>
	  	<p>
         <input type="submit" value="Valider" name="valider">
         <input type="reset" value="Annuler" name="annuler"> 
      </p>
</form>
</div>




