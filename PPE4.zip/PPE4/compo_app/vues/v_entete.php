<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<!-- TITRE ET MENUS -->
<html lang="fr">
    <head>
        <title>COMPO Match</title>
        <meta http-equiv="Content-Language" content="fr">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link href="util/cssGeneral.css" rel="stylesheet" type="text/css">
        <script src="jquery-2.0.3.min.js"></script>
        <script src="jquery-ui-1.10.4.custom/js/jquery-ui-1.10.4.custom.min.js"></script>
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
        <script src="util/jquery.listejoueur.js"></script>
        <script>
            $(function() {
                $( "#datepicker" ).datepicker();
                $( "#datepicker" ).datepicker( "option", "dateFormat", "yy/mm/dd" );
            });
        </script>
        <style type="text/css">
            .rouge{
                color: red;
            }
        </style>
    </head>
<body >