<div id="creationMatch">
    <table border="1">
        <tr><th>Date</th><th>Epreuve</th><th>Equipe domicile</th><th>Equipe exterieur</th><th>Composition</th></tr>
        <?php
        foreach($liste as $unmatch){
            $unclub1 = new ClubDAO();
            $clubdomicile = $unclub1->findById($unmatch->getClub1());
            $clubexterieur = $unclub1->findById($unmatch->getClub2());
            $cdomicile = $clubdomicile[0]->getNom();
            $cexterieur = $clubexterieur[0]->getNom();


            echo "<tr><td>".$unmatch->getDate()."</td>
        <td>".$unmatch->getEpreuve()."</td>";

            echo "<td>".$cdomicile."</td>
            <td>".$cexterieur."</td>";

            echo "<td><a href='index.php?uc=admin&action=modifmatch&idmatch=".$unmatch->getId()."'>Modifier le match</a></td>
        </tr>";

        }
        ?>
    </table>
</div>
