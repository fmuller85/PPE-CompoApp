<div id="clear" style="clear:both">
    Copyright - FFF 2014
</div>

</body>
</html>