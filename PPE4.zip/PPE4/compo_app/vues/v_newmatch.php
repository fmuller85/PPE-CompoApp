﻿<div id="creationMatch">
<form method="POST" action="index.php?uc=admin&action=newmatch">
   <fieldset>
     <legend>Nouvelle rencontre</legend>
		<p>
			<label for="date">Date de la rencontre (sous la forme AAAAMMJJ)</label>
			<input id="datepicker" type="text" name="date"" size="8" maxlength="8">
		</p>
       <br/>
		<p>
			<label for="epreuve">Epreuve :</label>
			 <input id="epreuve" type="text" name="epreuve" size="30" maxlength="50">
		</p>
        <p>
         <label for="domicile">Equipe à domicile :</label>
         <select id="domicile" name="domicile">
             <?php foreach ($liste as $c) { ?>
                <option value="<?php echo $c->getId(); ?>"><?php echo $c->getNom(); ?></option>
             <?php } ?>
         </select>
        </p>
       <p>
           <label for="exterieur">Equipe à l'extérieur :</label>
           <select id="exterieur" name="exterieur">
               <?php foreach ($liste as $c) { ?>
                   <option value="<?php echo $c->getId(); ?>"><?php echo $c->getNom(); ?></option>
               <?php } ?>
           </select>
       </p>
	  	<p>
         <input type="submit" value="Valider" name="valider">
         <input type="reset" value="Annuler" name="annuler"> 
      </p>
</form>
</div>





