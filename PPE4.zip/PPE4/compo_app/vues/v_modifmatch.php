<div id="modifmatch">
    <?php echo "id du match : ".$id; ?>
    <form method="POST" action="index.php?uc=admin&action=modifmatch">
        <fieldset>
            <legend>Modification du match </legend>
            <p>
                <label for="date">Date de la rencontre (sous la forme AAAAMMJJ)</label>
                <input id="date" type="text" name="date" size="8" maxlength="8" value="<?php echo $lematch[0]->getDate() ?>" />
            </p>
            <br/>
            <p>
                <label for="epreuve">Epreuve :</label>
                <input id="epreuve" type="text" name="epreuve" size="30" maxlength="50" value="<?php echo $lematch[0]->getEpreuve() ?>"/>
            </p>
            <p>
                <label for="domicile">Equipe à domicile :</label>
                <select id="domicile" name="domicile">
                    <?php foreach ($liste as $c) {
                        echo $clubdom[0]->getId();
                        echo '<option value="'.$c->getId().'"';
                        if ($c->getId() == $clubdom[0]->getId()){
                            echo ' selected>'.$c->getNom().'</option>';
                        }else{
                            echo '">'.$c->getNom().'</option>';
                        }
                    }
                    ?>
                </select>
            </p>
            <p>
                <label for="exterieur">Equipe à l'extérieur :</label>
                <select id="exterieur" name="exterieur">
                    <?php foreach ($liste as $c) {
                        echo $clubext[0]->getId();
                        echo '<option value="'.$c->getId().'"';
                        if ($c->getId() == $clubext[0]->getId()){
                            echo ' selected>'.$c->getNom().'</option>';
                        }else{
                            echo '">'.$c->getNom().'</option>';
                        }
                    }
                    ?>
                </select>
            </p>
            <p>
                <input type="submit" value="Modifier" name="modifier" >
                <input type="button" name="retour" value="Retour" />
                <input type="hidden" name="unidmatch" value="<?php echo $id; ?>">
            </p>
    </form>
</div>