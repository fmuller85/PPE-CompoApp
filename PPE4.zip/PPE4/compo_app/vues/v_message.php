<div class="message">
    <?php echo $message ?>
</div>