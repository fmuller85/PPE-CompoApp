<h3>Calendrier des matchs à venir</h3>
<h4>Votre club : <?php echo $leclub->getNom() ?></h4>
<table border="1">
    <tr><th>Date</th><th>Epreuve</th><th>Equipe domicile</th><th>Equipe exterieur</th><th>Composition</th></tr>
    <?php
    foreach($liste as $unmatch){
        $unclub1 = new ClubDAO();
        $clubdomicile = $unclub1->findById($unmatch->getClub1());
        $clubexterieur = $unclub1->findById($unmatch->getClub2());
        $cdomicile = $clubdomicile[0]->getNom();
        $cexterieur = $clubexterieur[0]->getNom();


        echo "<tr><td>".$unmatch->getDate()."</td>
        <td>".$unmatch->getEpreuve()."</td>";
        if($unmatch->getClub1() == $idclub){
            echo "<td style='background-color: yellow'>".$cdomicile."</td>
            <td>".$cexterieur."</td>";
        }
        if($unmatch->getClub2() == $idclub){
            echo "<td>".$cdomicile."</td>
            <td style='background-color: yellow'>".$cexterieur."</td>";
        }
            echo "<td><a href='index.php?uc=coach&action=choixtitu&idmatch=".$unmatch->getId()."'>Modifier sa compo</a></td>
        </tr>";

    }
    ?>
</table>
