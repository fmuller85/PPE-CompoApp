<div id="bandeau">
    <h1>
BIENVENUE SUR COMPO APP - La gestion des rencontres de la FFF
    </h1>
</div>
<!--  Menu haut-->
<ul id="menu">
	<li><a href="index.php?uc=accueil"> Accueil </a></li>
    <?php
    if(isset($_SESSION['uc'])){
        if($_SESSION['uc'] == 'admin'){
            echo '<li><a href="index.php?uc=admin&action=newmatch"> Nouveau match </a></li>';
            echo '<li><a href="index.php?uc=admin&action=listematch"> Liste des match </a></li>';
        }
        if($_SESSION['uc'] == 'coach'){
            echo '<li><a href="index.php?uc=coach&action=viewmatch"> Mes matchs </a></li>';
        }
        echo '<li><a href="index.php?uc='.$_SESSION['uc'].'&action=deconnexion"> Deconnexion </a></li>';
    }
    ?>
</ul>
