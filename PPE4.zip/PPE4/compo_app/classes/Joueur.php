<?php

class Joueur {
    // Variables
    private $_id;
    private $_nom;
    private $_prenom;
    private $_img;
    private $_datenaiss;
    private $_idclub;

    function __construct()
    {
    }

    /**
     * @param mixed $datenaiss
     */
    public function setDatenaiss($datenaiss)
    {
        $this->_datenaiss = $datenaiss;
    }

    /**
     * @return mixed
     */
    public function getDatenaiss()
    {
        return $this->_datenaiss;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->_id = $id;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->_id;
    }

    /**
     * @param mixed $idclub
     */
    public function setIdclub($idclub)
    {
        $this->_idclub = $idclub;
    }

    /**
     * @return mixed
     */
    public function getIdclub()
    {
        return $this->_idclub;
    }

    /**
     * @param mixed $img
     */
    public function setImg($img)
    {
        $this->_img = $img;
    }

    /**
     * @return mixed
     */
    public function getImg()
    {
        return $this->_img;
    }

    /**
     * @param mixed $nom
     */
    public function setNom($nom)
    {
        $this->_nom = $nom;
    }

    /**
     * @return mixed
     */
    public function getNom()
    {
        return $this->_nom;
    }

    /**
     * @param mixed $prenom
     */
    public function setPrenom($prenom)
    {
        $this->_prenom = $prenom;
    }

    /**
     * @return mixed
     */
    public function getPrenom()
    {
        return $this->_prenom;
    }




    public function toString() {
        return array(
            1  => $this->getId(),
            2 => $this->getNom(),
            3 => $this->getPrenom(),
            4 => $this->getImg(),
            5 => $this->getDatenaiss(),
            6 => $this->getIdclub()
        );
    }

}

?>
