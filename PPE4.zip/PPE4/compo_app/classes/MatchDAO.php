<?php
require_once('/classes/MysqlDAO.php');
require_once('/classes/Match.php');

class MatchDAO extends MysqlDAO {

    public function __construct(){
        parent::__construct();
    }

    public function create($lematch) {
        $date = $lematch->getDate();
        $epreuve = $lematch->getEpreuve();
        $club1 = $lematch->getClub1();
        $club2 = $lematch->getClub2();
        $sql = "INSERT INTO `match` (dateMatch, epreuvematch, club1, club2)
        VALUES ('$date', '$epreuve', '$club1', '$club2')";
        $this->connexion->exec($sql);
    }

    public function update($lematch){
        $date = $lematch->getDate();
        $epreuve = $lematch->getEpreuve();
        $club1 = $lematch->getClub1();
        $club2 = $lematch->getClub2();
        $sql = "UPDATE `match`
        SET dateMatch = '$date', epreuveMatch = '$epreuve' , club1 = '$club1' , club2 = '$club2'
        WHERE numMatch = ".$lematch->getId();

        $this->connexion->exec($sql);
        print_r($this->connexion->errorInfo());
    }

    public function delete($_id) {

    }

    public function findAll() {
        $sql = "SELECT * FROM `match` where dateMatch >= now() order by dateMatch asc";
        $requete_findAll=$this->connexion->query($sql);
        $liste=array();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $m = new Match();
            $m->setId($ligne->numMatch);
            $m->setEpreuve($ligne->epreuveMatch);
            $m->setDate($ligne->dateMatch);
            $m->setClub1($ligne->club1);
            $m->setClub2($ligne->club2);

            $liste[]=$m;
        }
        return $liste;
    }

    public function findById($_id) {
        $sql = "SELECT * FROM `match` where numMatch = $_id";
        $requete_findAll=$this->connexion->query($sql);
        $liste=array();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $m = new Match();
            $m->setId($ligne->numMatch);
            $m->setEpreuve($ligne->epreuveMatch);
            $m->setDate($ligne->dateMatch);
            $m->setClub1($ligne->club1);
            $m->setClub2($ligne->club2);

            $liste[]=$m;
        }
        return $liste;
    }

    public function findAllByClubId($idclub) {
        $sql = "SELECT * FROM `match` where dateMatch >= now() AND club1=".$idclub." OR dateMatch >= now() AND club2=".$idclub." order by dateMatch asc";
        $requete_findAll=$this->connexion->query($sql);
        $liste=array();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $m = new Match();
            $m->setId($ligne->numMatch);
            $m->setEpreuve($ligne->epreuveMatch);
            $m->setDate($ligne->dateMatch);
            $m->setClub1($ligne->club1);
            $m->setClub2($ligne->club2);


            $liste[]=$m;
        }
        return $liste;
    }

    public function createTitulaire($idMatch, $idClub, $idJoueur){
        $sql = "INSERT INTO `titulaire` VALUES ('null', '$idMatch', '$idClub', '$idJoueur')";
        $req = $this->connexion->exec($sql);

        print_r($this->connexion->errorInfo());
    }

    public function createRemplacant($idMatch, $idClub, $idJoueur){
        $sql = "INSERT INTO `remplacant` VALUES ('null', '$idMatch', '$idClub','$idJoueur')";
        $req = $this->connexion->exec($sql);

        print_r($this->connexion->errorInfo());
    }


    public function removeTitu($idMatch, $idJoueur){
        $sql = "Delete FROM titulaire WHERE idMatch = $idMatch AND idJoueur = $idJoueur";
        $this->connexion->exec($sql);

        print_r($this->connexion->errorInfo());
    }


    public function removeRemp($idMatch, $idJoueur){
        $sql = "Delete FROM remplacant WHERE idMatch = $idMatch AND idJoueur = $idJoueur";
        $this->connexion->exec($sql);

        print_r($this->connexion->errorInfo());
    }

}
?>