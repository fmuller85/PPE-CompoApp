<?php

class Match {
    // Variables
    private $_id;
    private $_date;
    private $_epreuve;
    private $_club1;
    private $_club2;

    function __construct()
    {
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->_id = $id;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->_id;
    }

    /**
     * @param mixed $club1
     */
    public function setClub1($club1)
    {
        $this->_club1 = $club1;
    }

    /**
     * @return mixed
     */
    public function getClub1()
    {
        return $this->_club1;
    }

    /**
     * @param mixed $club2
     */
    public function setClub2($club2)
    {
        $this->_club2 = $club2;
    }

    /**
     * @return mixed
     */
    public function getClub2()
    {
        return $this->_club2;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->_date = $date;
    }

    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->_date;
    }

    /**
     * @param mixed $epreuve
     */
    public function setEpreuve($epreuve)
    {
        $this->_epreuve = $epreuve;
    }

    /**
     * @return mixed
     */
    public function getEpreuve()
    {
        return $this->_epreuve;
    }


    public function toString() {
        return array(
            1  => $this->getId(),
            2 => $this->getDate(),
            3 => $this->getEpreuve(),
            4 => $this->getClub1(),
            5 => $this->getClub2()
        );
    }

}

?>
