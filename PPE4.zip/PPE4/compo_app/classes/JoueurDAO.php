<?php
require_once('/classes/MysqlDAO.php');
require_once('/classes/Joueur.php');

class JoueurDAO extends MysqlDAO {

    public function __construct(){
        parent::__construct();
    }

    public function create($_o) {

    }

    public function update($t) {

    }

    public function delete($_id) {

    }

    public function findAll() {
        $sql = "select * from joueur order by id_joueur asc";
        $requete_findAll=$this->connexion->query($sql);
        $liste=array();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $j = new Joueur();
            $j->setId($ligne->id_joueur);
            $j->setNom($ligne->nom_joueur);

            $liste[]=$j;
        }
        return $liste;
    }

    public function findAllByIdClub($_id) {
        $sql = "select * from joueur where id_club = ".$_id."";
        $requete_findAll=$this->connexion->query($sql);
        $liste=array();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $j = new Joueur();
            $j->setId($ligne->id_joueur);
            $j->setNom($ligne->nom_joueur);
            $j->setPrenom($ligne->prenom_joueur);

            $liste[]=$j;
        }
        return $liste;
    }

    public function findById($_id) {
        $sql = "select * from joueur where id_joueur = ".$_id."";
        $requete_findAll=$this->connexion->query($sql);
        $j = new Joueur();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $j->setId($ligne->id_joueur);
            $j->setNom($ligne->nom_joueur);
            $j->setPrenom($ligne->prenom_joueur);
        }
        return $j;
    }

    public function findAllTitu($idMatch, $idclub){
        $sql = "Select idJoueur from titulaire where idMatch = $idMatch AND idClub = $idclub";
        $requete_findAll=$this->connexion->query($sql);
        $liste=array();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $j = $this->findById($ligne->idJoueur);
            $liste[]=$j;
        }
        return $liste;

        print_r($this->connexion->errorInfo());
    }


    public function findAllRemp($idMatch, $idclub){
        $sql = "Select idJoueur from remplacant where idMatch = $idMatch AND idClub = $idclub";
        $requete_findAll=$this->connexion->query($sql);
        $liste=array();
        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $j = $this->findById($ligne->idJoueur);
            $liste[]=$j;
        }
        return $liste;

        print_r($this->connexion->errorInfo());
    }


}
?>