<?php
require_once('/classes/MysqlDAO.php');
require_once('/classes/Club.php');

class ClubDAO extends MysqlDAO {
	
    public function __construct(){
        parent::__construct();
    }

    public function create($_o) {

    }

    public function update($t) {

    }

    public function delete($_id) {

    }

public function findAll() {
    $sql = "select * from club order by numClub asc";
	$requete_findAll=$this->connexion->query($sql);
	$liste=array();
	while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
		$c = new Club();
        $c->setId($ligne->numClub);
        $c->setNom($ligne->nomClub);

		$liste[]=$c;
	}
	return $liste;
}

public function findById($_id) {
    $sql = "select * from `club` where numClub = '".$_id."'";
    $requete_findAll=$this->connexion->query($sql);

    while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
        $c = new Club();
        $c->setId($ligne->numClub);
        $c->setNom($ligne->nomClub);

        $liste[]=$c;
    }
    return $liste;
}

    public function findByLog($login, $mdp) {
        $sql = "select * from club where codeFFF = '".$login."' and mdpClub = '".$mdp."'";
        $requete_findAll=$this->connexion->query($sql);

        while ($ligne=$requete_findAll->fetch(PDO::FETCH_OBJ)){
            $c = new Club();
            $c->setId($ligne->numClub);
            $c->setNom($ligne->nomClub);
            $c->setAdresse($ligne->adresseClub);
            $c->setCp($ligne->cpClub);
            $c->setVille($ligne->villeClub);
            $c->setTel($ligne->telClub);
            $c->setMail($ligne->mailClub);
            $c->setImg($ligne->imgClub);

        }
        return $c;
    }

}
?>