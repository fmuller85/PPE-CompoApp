﻿<?php
require_once('/classes/ClubDAO.php');
require_once('/classes/MatchDAO.php');

$action = $_REQUEST['action'];
switch($action)
{
    case 'newmatch':
    {

        if(isset($_POST['valider'])){

            $datematch = $_POST['date'];
            $epreuve = $_POST['epreuve'];
            $club1 = $_POST['domicile'];
            $club2 = $_POST['exterieur'];

            $unmatch = new Match();
            $unmatch->setDate($datematch);
            $unmatch->setEpreuve($epreuve);
            $unmatch->setClub1($club1);
            $unmatch->setClub2($club2);

            $match = new MatchDAO();
            $match->create($unmatch);


            $message ="Match crée ! <a href='index.php?uc=admin&action=newmatch'>Revenir à la création dun match</a>";
            include("vues/v_message.php");
            }else{
                $dao = new ClubDAO();
                $liste = $dao->findAll();
                include("vues/v_newmatch.php");
            }
        break;
    }

    case 'deconnexion':
    {
        $_SESSION = [];
        session_destroy();
        header("Refresh: 0; url=index.php?uc=accueil");
        break;
    }

    case 'listematch':
    {
        $dao = new MatchDAO();
        $liste = $dao->findAll();
        $match = new MatchDAO();
        $lesmatch = $match->findAll();
        include ("vues/v_listematch.php");
        break;
    }

    case 'modifmatch':
    {
        $match = new MatchDAO();
        $dao = new ClubDAO();
        if(isset($_POST['modifier'])){
            $idmatch = $_POST['unidmatch'];
            $datematch = $_POST['date'];
            $epreuve = $_POST['epreuve'];
            $club1 = $_POST['domicile'];
            $club2 = $_POST['exterieur'];
            $_POST['date']=$datematch;
            $_POST['epreuve']=$epreuve;
            $_POST['domicile']=$club1;
            $_POST['exterieur']=$club2;

            $unmatch = new Match();
            $unmatch->setId($idmatch);
            $unmatch->setDate($datematch);
            $unmatch->setEpreuve($epreuve);
            $unmatch->setClub1($club1);
            $unmatch->setClub2($club2);

            $match->update($unmatch);

            $message ="Match modifié ! <a href='index.php?uc=admin&action=listematch'>Revenir à la liste des matchs</a>";
            include("vues/v_message.php");

        }else{
            $id = $_GET['idmatch'];
            $liste = $dao->findAll();
            $lematch = $match->findById($id);
            $idclub1 = $lematch[0]->getClub1();
            $clubdom = $dao->findById($idclub1);
            $idclub2 = $lematch[0]->getClub2();
            $clubext = $dao->findById($idclub2);
            include("vues/v_modifmatch.php");
        }
        break;
    }
}
?>

