<?php
require_once('/classes/Joueur.php');
require_once('/classes/JoueurDAO.php');
require_once('/classes/Club.php');
require_once('/classes/ClubDAO.php');
require_once('/classes/Match.php');
require_once('/classes/MatchDAO.php');

$action = $_REQUEST['action'];
switch($action)
{
    case 'viewmatch':
    {
        $leclub = unserialize($_SESSION['objclub']);
        $idclub = $leclub->getId();
        $lesmatch = new MatchDAO();
        $liste = $lesmatch->findAllByClubId($idclub);
        include("vues/v_match.php");
        break;
    }

    case 'choixtitu':
    {
        $leclub = unserialize($_SESSION['objclub']);
        $idclub = $leclub->getId();
        $idmatch = $_GET['idmatch'];
        $joueur = new JoueurDAO();
        $listeJoueur = $joueur->findAllByIdClub($idclub);
        $listeTitu = $joueur->findAllTitu($idmatch, $idclub);
        $listeRemp = $joueur->findAllRemp($idmatch, $idclub);
        $joueurSelectionne = array_merge($listeTitu, $listeRemp);
        include("vues/v_choixtitu.php");
        break;
    }

    case 'deconnexion':
    {
        $_SESSION['uc'] = [];
        $_SESSION['club'] = [];
        $_SESSION['objclub'] = [];
        session_destroy();
        header("Refresh: 0; url=index.php?uc=accueil");
        break;
    }
}
?>

