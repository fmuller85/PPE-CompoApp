<?php
session_start();
include("vues/v_entete.php") ;
include("vues/v_bandeau.php") ;

if(!isset($_REQUEST['uc']))
     $uc = 'accueil';
else
	$uc = $_REQUEST['uc'];

switch($uc)
{
	case 'accueil':
		{
            include("vues/v_accueil.php");
            if(isset($_SESSION['uc'])){
                echo "Bienvenue ".$_SESSION['uc'];
            }else{
                include("vues/v_login.php");
            }
            break;
        }
    case 'admin':
        {include("controleurs/c_gestionMatchs.php");break;}
    case 'coach':
        {include("controleurs/c_gestionClub.php");break;}
}
include("vues/v_pied.php") ;
?>

