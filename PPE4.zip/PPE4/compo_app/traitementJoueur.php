<?php
require_once('/classes/Joueur.php');
require_once('/classes/JoueurDAO.php');
require_once('/classes/MatchDAO.php');

    if(isset($_POST['action'])){
        if(isset($_POST['joueur']) & isset($_POST['match'])){
            $idjoueur = $_POST['joueur'];
            $idmatch = $_POST['match'];
            $idclub = $_POST['club'];
            $mdao = new MatchDAO();
            $jdao = new JoueurDAO();

            switch ($_POST['action']){
                case 'ajouterTitu':
                {
                    $mdao->createTitulaire($idmatch, $idclub, $idjoueur); // On ajoute un titulaire
                    break;
                }

                case 'ajouterRemp':
                {
                    $mdao->createRemplacant($idmatch, $idclub, $idjoueur); // on ajoute un remplacant
                    break;
                }

                case 'supprimerTitu':
                {
                    $mdao->removeTitu($idmatch, $idjoueur); // on supprime un titulaire
                    break;
                }

                case 'supprimerRemp':
                {
                    $mdao->removeRemp($idmatch, $idjoueur); // On supprime un remplacant
                    break;
                }

                case 'tituToRemplacant':
                {
                    $mdao->createRemplacant($idmatch, $idclub, $idjoueur); // on ajoute un remplacant
                    $mdao->removeTitu($idmatch, $idjoueur); // on supprime un titulaire
                    break;
                }

                case 'remplacantTotitu':
                {
                    $mdao->createTitulaire($idmatch, $idclub, $idjoueur); // On ajoute un titulaire
                    $mdao->removeRemp($idmatch, $idjoueur); // On supprime un remplacant
                    break;
                }
            }
        }
    }
?>